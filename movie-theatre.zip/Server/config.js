module.exports = {
  MONGO_URI: process.env.MONGO_URI || 'mongodb://localhost:27017/videos/'
};


//VanTiger:vanblog21@ds161740.mlab.com:61740/movie-theatre
